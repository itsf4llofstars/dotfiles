# Notes on Lua Setup of Neovim

1. Find if better '[a', ']a', mappings are needed in treesitter swap section
    of treesitter settings in init.vim
2. Look at installing telescope-fzf-native : See kickstarter
