# Lazy Vim Setup

Taken from [LazyVim](https://lazyvim.org)

The lazy git branch is off the lua_init branch

## Pre Backup

This commit is pre-backup of .local/share/nvim, .local/state/nvim,
.cache/nvim

The backups are named nvim.bak.lua

The .config/nvim directory's files will be tar'd to the ~/archives directory
