-- [[ Settings sb ]]
vim.opt.guicursor = ""
vim.opt.termguicolors = true
-- vim.cmd([[colorscheme retrobox]])

vim.opt.number = true
vim.opt.relativenumber = true
vim.opt.timeout = true
vim.opt.timeoutlen = 1000 -- may want 500

vim.opt.tabstop = 4
vim.opt.shiftwidth = 4
vim.opt.softtabstop = 4
vim.opt.textwidth = 0
vim.opt.expandtab = true
vim.opt.wrap = false

vim.opt.autochdir = false
vim.opt.breakindent = true
vim.opt.clipboard = 'unnamedplus'
-- vim.opt.colorcolumn = '80'
vim.opt.cursorlineopt = 'number'
vim.opt.completeopt = 'menuone,preview'
vim.opt.cursorline = true
vim.opt.foldlevel = 1
vim.opt.foldlevelstart = 1
vim.opt.foldmethod = 'indent'
vim.opt.foldenable = false
vim.opt.hlsearch = false
vim.opt.ignorecase = true
vim.opt.incsearch = true
vim.opt.laststatus = 2
-- vim.opt.statusline='(%n) %F %h%m%r %Y    %c,%l:%L    %p%%'
vim.opt.lazyredraw = true
vim.opt.list = true
vim.opt.mouse = 'a'
vim.opt.ruler = false
vim.opt.smartcase = true
vim.opt.smartindent = true
vim.opt.scrolloff = 5
vim.opt.showmatch = true
vim.opt.signcolumn = 'yes'
vim.opt.updatetime = 300

vim.opt.swapfile = false
vim.opt.backup = false
vim.opt.undofile = true

vim.g.mapleader = ' '
vim.g.maplocalleader = '\\'

