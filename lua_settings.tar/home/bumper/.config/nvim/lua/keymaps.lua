-- [[ Basic Keymaps bk ]]
-- [[ Contents ]]
-- functions
-- general mappings
-- wrappers
-- splits
-- telescope

-- general mappings
vim.keymap.set({ 'n', 'v' }, '<Space>', '<Nop>', { silent = true })
vim.keymap.set('n', 'k', "v:count == 0 ? 'gk' : 'k'", { expr = true, silent = true })
vim.keymap.set('n', 'j', "v:count == 0 ? 'gj' : 'j'", { expr = true, silent = true })

vim.keymap.set({ 'i', 'v' }, 'kj', '<ESC>', { noremap = true })

vim.keymap.set({ 'n' }, '<leader>w', ':write<CR>', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>q', 'ZQ', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>z', 'ZZ', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<localleader>e', ':edit ~/.config/nvim/init.lua<CR>', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>o', ':edit .<CR>', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>t', ':terminal<CR>', { noremap = true, silent = true })
vim.keymap.set({ 't' }, '<ESC>', '<C-\\><C-n>', { noremap = true, silent = true })
vim.keymap.set({ 't' }, '<C-v><ESC>', '<ESC>', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>mp','<CMD>!tt<CR><CR>', { noremap = true, silent =true })

vim.keymap.set({ 'n' }, '<leader>p', '"+p', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, "'", "`", { noremap = true, silent = true })
vim.keymap.set({ 'n' }, "''", "``", { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<S-b>', '_', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<S-e>', '$', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<S-y>', 'y$', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, 'w', 'W', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<S-n>', 'Nzz', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, 'n', 'nzz', { noremap = true, silent = true })

vim.keymap.set({ 'n' }, '<leader>in', ":normal! mpHmogg=G'ozt`p<CR>", { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>bn', ':bnext<CR>', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>bp', ':bprevious<CR>', { noremap = true, silent = true })

vim.keymap.set({ 'n' }, '<leader>a', 'zt', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<F8>', '@', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<F9>', '@@', { noremap = true, silent = true })
vim.keymap.set({ 'v' }, '<S-j>', ":m '>+1<CR>gv=gv", { noremap = true, silent = true })
vim.keymap.set({ 'v' }, '<S-k>', ":m '<-2<CR>gv=gv", { noremap = true, silent = true })
vim.keymap.set({ 'v' }, '>', '>gv', { noremap = true, silent = true })
vim.keymap.set({ 'v' }, '<', '<gv', { noremap = true, silent = true })

-- wrappers
vim.keymap.set({ 'n' }, "<leader>'", "viw<ESC>a'<ESC>bi'<ESC>lel", { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>"', 'viw<ESC>a"<ESC>bi"<ESC>lel', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>(', 'viw<ESC>a)<ESC>bi(<ESC>lel', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader', 'viw<ESC>a}<ESC>b{<ESC>lel', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>[', 'viw<ESC>a]<ESC>bi[<ESC>lel', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader><', 'viw<ESC>a><ESC>bi<<ESC>lel', { noremap = true, silent = true })

-- splits
vim.keymap.set({ 'n' }, '<leader>to', '<CMD>tabnew<CR>', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>tn', '<CMD>tabnext<CR>', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>tp', '<CMD>tabprevious<CR>', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>tc', '<CMD>tabclose<CR>', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>v', '<C-w>v<C-w>l', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<leader>s', '<C-w>s<C-w>j', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<C-h>', '<C-w>h', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<C-j>', '<C-w>j', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<C-k>', '<C-w>k', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<C-l>', '<C-w>l', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<localleader>hh', ':vertical resize+5<CR>', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<localleader>ll', ':vertical resize-5<CR>', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<localleader>kk', ':resize+5<CR>', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<localleader>jj', ':resize-5<CR>', { noremap = true, silent = true })
vim.keymap.set({ 'n' }, '<localleader>rs', ':<C-w>=', { noremap = true, silent = true })

-- telescope
local builtin = require('telescope.builtin')
vim.keymap.set('n', '<leader>ff', builtin.find_files, {})
vim.keymap.set('n', '<leader>fg', builtin.live_grep, {})
vim.keymap.set('n', '<leader>fb', builtin.buffers, {})
vim.keymap.set('n', '<leader>fh', builtin.help_tags, {})
vim.keymap.set('n', '<leader>fo', builtin.oldfiles, {})
vim.keymap.set('n', '<leader>fm', builtin.marks, {})
vim.keymap.set('n', '<leader>fc', builtin.colorscheme, {})
vim.keymap.set('n', '<leader>fr', builtin.registers, {})
vim.keymap.set('n', '<leader>fk', builtin.keymaps, {})
vim.keymap.set('n', '<leader>fz', builtin.current_buffer_fuzzy_find, {})
vim.keymap.set('n', '<leader>fst', builtin.git_status, {})
vim.keymap.set('n', '<leader>fsg', builtin.git_files, {})
vim.keymap.set('n', '<leader>fss', builtin.git_stash, {})
vim.keymap.set('n', '<leader>ft', builtin.treesitter, {})
