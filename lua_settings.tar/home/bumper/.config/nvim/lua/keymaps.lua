-- [[ Basic Keymaps bk ]]
-- [[ Contents ]]
-- functions
-- general mappings
-- wrappers
-- tabs
-- splits
-- telescope

-- functions
function Map(mode, lhs, rhs)
  vim.keymap.set(mode, lhs, rhs, { remap = false, silent = true })
end

function Nmap(lhs, rhs)
  Map('n', lhs, rhs)
end

function Imap(lhs, rhs)
  Map('i', lhs, rhs)
end

function Vmap(lhs, rhs)
  Map('v', lhs, rhs)
end

function Tmap(lhs, rhs)
  Map('t', lhs, rhs)
end

-- general mappings
vim.keymap.set({ 'n', 'v' }, '<Space>', '<Nop>', { silent = true })
vim.keymap.set('n', 'Q', '<Nop>', { silent = true })
vim.keymap.set('n', 'k', "v:count == 0 ? 'gk' : 'k'", { expr = true, silent = true })
vim.keymap.set('n', 'j', "v:count == 0 ? 'gj' : 'j'", { expr = true, silent = true })


Imap('kj', '<ESC>')
Vmap('kj', '<ESC>')

Nmap('<leader>w', vim.cmd.write)
Nmap('<leader>q', vim.cmd.quit)
Nmap('<leader>z', '<CMD>write<CR>:<CMD>quit<CR>')

vim.keymap.set('n', '<localleader>w', function()
  vim.cmd('wall')
end)

vim.keymap.set('n', '<localleader>z', function()
  vim.cmd('xall')
end)

Nmap('<leader>o', '<CMD>NvimTreeOpen<CR>')
Nmap('<leader>t', ':terminal<CR>')
Nmap('<leader>mp','<CMD>!tt<CR><CR>')
Tmap('<ESC>', '<C-\\><C-n>')
Tmap('<C-v><ESC>', '<ESC>')

Vmap('<leader>d', '"_dP')
Nmap('<C-f>', '<C-d>')
Nmap('cw', 'bce')
Nmap('<leader>p', '"+p')
Nmap("'", "`")
Nmap("''", "``")
Nmap('B', '_')
Nmap('E', '$')
Nmap('Y', 'y$')
Nmap('w', 'W')
Nmap('N', 'Nzz')
Nmap('n', 'nzz')

Nmap('<leader>*', [[:%s/\<<C-r><C-w>\>//gI<Left><Left><Left>]])
Nmap('<leader>&', [[:%s/\<<C-r><C-w>\>//gIc<Left><Left><Left><Left>]])

Nmap('<leader>in', ":normal! mpHmogg=G'ozt`p<CR>")
Nmap('<leader>bn', ':bnext<CR>')
Nmap('<leader>bp', ':bprevious<CR>')
Nmap('<leader>a', 'zt')
Nmap('<F8>', '@')
Nmap('<F9>', '@@')
Vmap('<C-DOWN>', ":m '>+1<CR>gv=gv")
Vmap('<C-UP>', ":m '<-2<CR>gv=gv")
Vmap('>', '>gv')
Vmap('<', '<gv')

-- wrappers
Nmap("<leader>'", "viw<ESC>a'<ESC>bi'<ESC>lel")
Nmap('<leader>"', 'viw<ESC>a"<ESC>bi"<ESC>lel')
Nmap('<leader>(', 'viw<ESC>a)<ESC>bi(<ESC>lel')
Nmap('<leader', 'viw<ESC>a}<ESC>b{<ESC>lel')
Nmap('<leader>[', 'viw<ESC>a]<ESC>bi[<ESC>lel')
Nmap('<leader><', 'viw<ESC>a><ESC>bi<<ESC>lel')

-- tabs
Nmap('<leader>to', '<CMD>tabnew<CR>')
Nmap('<leader>tc', '<CMD>tabclose<CR>')
Nmap('L', '<CMD>bnext<CR>')
Nmap('H', '<CMD>bprev<CR>')
Nmap('K', 'g<Tab>')

-- splits
Nmap('<leader>v', '<C-w>v<C-w>l')
Nmap('<localleader>v', '<C-w>s<C-w>j')
Nmap('<C-h>', '<C-w>h')
Nmap('<C-j>', '<C-w>j')
Nmap('<C-k>', '<C-w>k')
Nmap('<C-l>', '<C-w>l')
Nmap('<leader>ll', ':resize-')
Nmap('<leader>kk', ':resize+')
Nmap('<leader>rs', ':<C-w>=')

-- zen mode
Nmap('<leader>ez', '<CMD>ZenMode<CR>')

-- telescope
local builtin = require('telescope.builtin')
vim.keymap.set('n', '<leader>ff', builtin.find_files, {})
vim.keymap.set('n', '<leader>fg', builtin.live_grep, {})
vim.keymap.set('n', '<leader>fb', builtin.buffers, {})
vim.keymap.set('n', '<leader>fh', builtin.help_tags, {})
vim.keymap.set('n', '<leader>fo', builtin.oldfiles, {})
vim.keymap.set('n', '<leader>fm', builtin.marks, {})
vim.keymap.set('n', '<leader>fc', builtin.colorscheme, {})
vim.keymap.set('n', '<leader>fr', builtin.registers, {})
vim.keymap.set('n', '<leader>fk', builtin.keymaps, {})
vim.keymap.set('n', '<leader>fz', builtin.current_buffer_fuzzy_find, {})
vim.keymap.set('n', '<leader>fst', builtin.git_status, {})
vim.keymap.set('n', '<leader>fsg', builtin.git_files, {})
vim.keymap.set('n', '<leader>fss', builtin.git_stash, {})
vim.keymap.set('n', '<leader>ft', builtin.treesitter, {})
