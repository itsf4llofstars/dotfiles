-- Packer Package Manager

local ensure_packer = function()
  local fn = vim.fn
  local install_path = fn.stdpath('data')..'/site/pack/packer/start/packer.nvim'
  if fn.empty(fn.glob(install_path)) > 0 then
    fn.system({'git', 'clone', '--depth', '1', 'https://github.com/wbthomason/packer.nvim', install_path})
    vim.cmd [[packadd packer.nvim]]
    return true
  end
  return false
end

local packer_bootstrap = ensure_packer()

return require('packer').startup(function(use)
  use 'wbthomason/packer.nvim'

  use {
    'nvim-treesitter/nvim-treesitter',
    dependencies = {
      'nvim-treesitter/nvim-treesitter-textobjects',
    },
    run = ':TSUpdate'
  }

  use {
    'nvim-telescope/telescope.nvim', branch = '0.1.x',
    requires = {'nvim-lua/plenary.nvim'},
  }

  use {
    'williamboman/mason.nvim',
    requires = {
      'williamboman/mason-lspconfig',
      'neovim/nvim-lspconfig',
      'folke/neodev.nvim',
    },
    run = ':MasonUpdate',
  }

  use {
    'hrsh7th/nvim-cmp',
    requires = {
      'L3MON4D3/LuaSnip',
      'saadparwaiz1/cmp_luasnip',
      'hrsh7th/cmp-nvim-lsp',
      'rafamadriz/friendly-snippets',
    },
  }

  use {
    'nvim-lualine/lualine.nvim',
    requires = {
      'kyazdani42/nvim-web-devicons',
      'arkav/lualine-lsp-progress',
    },
  }

  use {
    'akinsho/bufferline.nvim',
    tag = "*",
    requires = {
      'nvim-tree/nvim-web-devicons',
    },
  }

  use {
    'nvim-tree/nvim-tree.lua',
    requires = {
      'nvim-tree/nvim-web-devicons',
    },
  }

  use { 'folke/which-key.nvim' }
  use { 'catppuccin/nvim', as = 'catppuccin' }
  use { 'ellisonleao/gruvbox.nvim', as = 'gruvbox' }
  use { 'lukas-reineke/indent-blankline.nvim' }
  use { 'folke/zen-mode.nvim' }
  -- use ( 'mattn/emmet-vim' }

  if packer_bootstrap then
    require('packer').sync()
  end
end)

