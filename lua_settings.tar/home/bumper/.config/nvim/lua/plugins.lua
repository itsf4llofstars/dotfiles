-- Packer Package Manager

-- [[ Packer Bootstrap ]] <<<
local ensure_packer = function()
  local fn = vim.fn
  local install_path = fn.stdpath('data')..'/site/pack/packer/start/packer.nvim'
  if fn.empty(fn.glob(install_path)) > 0 then
    fn.system({'git', 'clone', '--depth', '1', 'https://github.com/wbthomason/packer.nvim', install_path})
    vim.cmd [[packadd packer.nvim]]
    return true
  end
  return false
end -- >>>

local packer_bootstrap = ensure_packer()

-- [[ Packer and Plugins ]] <<<
return require('packer').startup(function(use)
  use 'wbthomason/packer.nvim'

  -- [[ Treesitter ]] <<<
  use {
    'nvim-treesitter/nvim-treesitter',
    dependencies = {
      'nvim-treesitter/nvim-treesitter-textobjects',
    },
    run = ':TSUpdate'
  } -- >>>

  -- [[ Telescope ]] <<<
  use {
    'nvim-telescope/telescope.nvim', branch = '0.1.x',
    requires = { {'nvim-lua/plenary.nvim'} }
  } -- >>>

  -- [[ Which Key ]] <<<
  use {
    'folke/which-key.nvim',
  } -- >>>

  -- [[ Mason, Mason-lspconfig, Nvim-lspconfig ]] <<<
  use {
    'williamboman/mason.nvim',
    requires = {
      'williamboman/mason-lspconfig',
      'neovim/nvim-lspconfig',
      'folke/neodev.nvim',
      -- { 'j-hui/fidget.nvim', tag = 'legacy' },
    },
    run = ':MasonUpdate',
  } -- >>>

  -- [[ Completion ]] <<<
  use {
    'hrsh7th/nvim-cmp',
    requires = {
      'L3MON4D3/LuaSnip',
      'saadparwaiz1/cmp_luasnip',
      'hrsh7th/cmp-nvim-lsp',
      'rafamadriz/friendly-snippets',
    },
  } -- >>>

  -- [[ Catppuccin ]] <<<
  use { "catppuccin/nvim", as = "catppuccin" }
  -- >>>

  if packer_bootstrap then
    require('packer').sync()
  end

  -- lua-line
  -- use {'nvim-lualine/lualine.nvim', requires = { 'nvim-tree/nvim-web-devicons', opt = true }}

  use {
    "lukas-reineke/indent-blankline.nvim"
  }
end) -- >>>

-- vim:fmr=<<<,>>>:fdm=marker:
