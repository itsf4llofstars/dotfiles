-- [[ Augroups and Autocmds ]
local ALL = vim.api.nvim_create_augroup('all_files', { clear = true })
local VIM_LUA = vim.api.nvim_create_augroup('vim_lua_files', { clear = true })
local PYTHON = vim.api.nvim_create_augroup('python3', { clear = true })
-- local TEXT = vim.api.nvim_create_augroup('text_files', { clear = true })
-- local C = vim.api.nvim_create_augroup('c_files', { clear = true})
--
vim.api.nvim_create_autocmd({ 'InsertEnter' }, {
  pattern = { '*' },
  group = ALL,
  command = 'set nornu',
  desc = 'Turn off relative numbers on Insert mode',
})

vim.api.nvim_create_autocmd({ 'InsertLeave' }, {
  pattern = { '*' },
  group = ALL,
  command = 'set rnu',
  desc = 'Turn on relative numbers leaving Insert mode',
})

vim.api.nvim_create_autocmd({ 'BufWritePre' }, {
  pattern = { '*.vim', '*.lua', '*.c', '*.h' },
  group = ALL,
  command = ":normal! mpHmogg=G'ozt`p",
  desc = 'Indent file buffer write',
})

vim.api.nvim_create_autocmd({'BufWritePre'}, {
  pattern = { '*' },
  group = ALL,
  command = '%s/\\s\\+$//e',
})

vim.api.nvim_create_autocmd({ 'FileType' }, {
  pattern = { 'vim', 'lua' },
  group = VIM_LUA,
  command = 'silent setlocal ts=2 sw=2 tw=0 fdm=indent fmr=<<<,>>> fdm=marker cc=90',
  desc = 'Filetype settings for vim and lua files',
})

vim.api.nvim_create_autocmd({ 'FileType' }, {
  pattern = { 'python' },
  group = PYTHON,
  command = 'silent setlocal cc=90',
  desc = 'FileType settings for python',
})

vim.api.nvim_create_autocmd({ 'BufEnter' }, {
  pattern = { '*.py' },
  group = PYTHON,
  command = 'nnoremap <F5> :!python3 %<CR>',
  desc = 'Run python3 script',
})

vim.api.nvim_create_autocmd({ 'BufEnter' }, {
  pattern = { '*.py' },
  group = PYTHON,
  command = 'nnoremap <F6> :!black %<CR>',
  desc = 'Run black on python3 script',
})

vim.api.nvim_create_autocmd({ 'BufEnter' }, {
  pattern = { '*.py' },
  group = PYTHON,
  command = 'nnoremap <F7> :!pylint %<CR>',
  desc = 'Run pylint on python3 script',
})

vim.api.nvim_create_autocmd({ 'FileType' }, {
  pattern = { 'python' },
  group = PYTHON,
  command = 'unmap <leader>bn',
  desc = 'Remove the leader bn map',
})

vim.api.nvim_create_autocmd({ 'FileType' }, {
  pattern = { 'python' },
  group = PYTHON,
  command = 'unmap <leader>bp',
  desc = 'Remove the leader bp map',
})

vim.api.nvim_create_autocmd({ 'BufEnter' }, {
  pattern = { '*.py' },
  group = PYTHON,
  command = 'nnoremap <leader>b :bnext<CR>',
  desc = 'Swith to next buffer on leader b',
})

-- vim.api.nvim_create_autocmd({ 'FileType' }, {
  --   pattern = { 'c' },
  --   group = C,
  --   command = 'silent setlocal ts=8 sw=8 noai nosi noci cin cino=ln,c2 fdm=indent',
  --   desc = 'FileType settings for c',
  -- })
